%%
% Nume si prenume: TODO
%

clearvars
clc

%% Magic numbers (replace with received numbers)
m = 4; 
n = 24; 

%% Process data (fixed, do not modify)
c1 = (1000+n*300)/10000;
c2 = (1.15+2*(m+n/10)/20);
a1 = 2*c2*c1;
a2 = c1;
b0 = (1.2+m+n)/5.5;

rng(m+10*n)
x0_slx = [2*(m/2+rand(1)*m/5); m*(n/20+rand(1)*n/100)];

%% Experiment setup (fixed, do not modify)
Ts = 10*c2/c1/1e4*1.5; % fundamental step size
Tfin = 30*c2/c1*10; % simulation duration

gain = 10;
umin = 0; umax = gain; % input saturation
ymin = 0; ymax = b0*gain/1.5; % output saturation

whtn_pow_in = 1e-6*5*(((m-1)*8+n/2)/5)/2*6/8; % input white noise power and sampling time
whtn_Ts_in = Ts*3;
whtn_seed_in = 23341+m+2*n;
q_in = (umax-umin)/pow2(10); % input quantizer (DAC)

whtn_pow_out = 1e-5*5*(((m-1)*25+n/2)/5)*6/80*(0.5+0.3*(m-2)); % output white noise power and sampling time
whtn_Ts_out = Ts*5;
whtn_seed_out = 23342-m-2*n;
q_out = (ymax-ymin)/pow2(9); % output quantizer (ADC)

u_op_region = (m/2+n/5)/2; % operating point

%% Input setup (can be changed/replaced/deleted)
% u0 = 0;     % fixed
% ust = 4*m;  % must be modified (saturation)
% t1 = 12/a1; % recommended 

wf = 1/4; % in cazul nostru 1/T1 unde T1 e const dominanta, usor de aprox din step

fmin = wf/2/pi/10;
fmax = wf/2/pi*10;
a_in = 1.48; %arbitrar, suf. de mare incat sa depaseasca nivelul zgomotului


%% Data acquisition (use t, u, y to perform system identification)
out = sim("circuit_hidraulic_R2022b.slx");

t = out.tout;
u = out.u;
y = out.y;

plot(t,u,t,y)
shg

%% System identification

y_st = (18.59+17.48)/2;
u_st = 3.4; %u_op_region dat deja in simulink

K = y_st/u_st;

w1 = pi/(222.361-218.677);
dT1 = 220.517-218.677;
phi1 = rad2deg(-w1*dT1) ;

w2 = pi/(365.992-363.788);
dT2 = 365.112-363.788;
phi1 = rad2deg(-w2*dT2) ;

Ay = (20.1165-15.8996)/2;
Au = 1.48; %cat am pus noi in gain

M = Ay/Au;
Im = -M;

wn = w1;
zeta = -K/2/Im;

H = tf(K*wn^2,[1,2*wn*zeta,wn^2]);
zpk(H)
T1 = 1/0.2485;
T2 = 1/2.927;


%K = 5
A = [0,1;-1/T1/T2,-(1/T1+1/T2)];
B = [0;K/T1/T2];
C = [1,0];
D = 0;
sys = ss(A,B,C,D);
y_sim2 = lsim(sys,u,t,[y(1),0]);

figure
plot(t,u,t,y,t,y_sim2)

J = 1/sqrt(length(t))*norm(y-y_sim2)
eMPN = norm(y-y_sim2)/norm(y-mean(y))*100